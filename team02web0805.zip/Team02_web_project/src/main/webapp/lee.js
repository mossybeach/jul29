const navBtn = document.querySelector(".navIcon");
const navMenu = document.querySelector(".menu");
const boardBtn1 = document.querySelector(".btn1");
const boardBtn2 = document.querySelector(".btn2");
const boardBtn3 = document.querySelector(".btn3");
const boardBtn4 = document.querySelector(".btn4");
const boardMain = document.querySelector("main");
const boardDetails = document.querySelector(".board-details");
const newtab = document.querySelector(".btn4");
const btnValue1 = boardBtn1.getAttribute('data-btn');
const btnValue2 = boardBtn2.getAttribute('data-btn');
const btnValue3 = boardBtn3.getAttribute('data-btn');
const tbody = document.querySelector('.table-body');
navBtn.addEventListener("click", () => {
	navMenu.classList.toggle("active");
});

boardBtn1.addEventListener("click", (e) => {
	boardMain.style.backgroundColor = "#e3c099";
	fetch('leeshow.jsp', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/x-www-form-urlencoded'
		},
		body: new URLSearchParams({
			btn: btnValue1
		})
	}).then(response => response.text())
		.then(html => {
			boardDetails.innerHTML = html;
		})
		.catch(error => console.error('Error loading table:', error));

});
boardBtn2.addEventListener("click", (e) => {
	boardMain.style.backgroundColor = "#c38452";
	fetch('leeshow.jsp', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/x-www-form-urlencoded'
		},
		body: new URLSearchParams({
			btn: btnValue2
		})
	}).then(response => response.text())
		.then(html => {
			boardDetails.innerHTML = html;
		})
		.catch(error => console.error('Error loading btnNo', error));

});

boardBtn3.addEventListener("click", (e) => {
	boardMain.style.backgroundColor = "#6b3e2e";
	fetch('leeshow.jsp', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/x-www-form-urlencoded'
		},
		body: new URLSearchParams({
			btn: btnValue3
		})
	}).then(response => response.text())
		.then(html => {
			boardDetails.innerHTML = html;
		})
		.catch(error => console.error('Error loading btnNo', error));

});
const toBoard = () => {
	boardMain.style.backgroundColor = "#a1785c";
	boardDetails.innerHTML = "";
	fetch('leeboard.jsp')
		.then(response => response.text())
		.then(html => {
			boardDetails.innerHTML = html;
		})
		.catch(error => console.error('Error loading bno', error));

}
newtab.addEventListener("click", toBoard);

let btnCount = 0;

function showDetail(bno) {
	//console.log('BNO received:', bno);
	boardDetails.innerHTML = "";

	switch (btnCount) {
		case 0:
			boardMain.style.backgroundColor = "#e3c099";
			console.log(btnCount);
			btnCount += 1;
			break;

		case 1:
			boardBtn2.classList.add("active");
			boardMain.style.backgroundColor = "#c38452";
			console.log(btnCount);
			btnCount += 1;
			break;

		case 2: boardMain.style.backgroundColor = "#6b3e2e";
			boardBtn3.classList.add("active");
			console.log(btnCount);
			btnCount += 1;

			break;

		default:
			alert("max tab reached, please close a tab");
			break;
	}
	if (btnCount > 3) {
		alert("max tab reached, please close a tab");
	}

	fetch('leedetail.jsp', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/x-www-form-urlencoded'
		},
		body: new URLSearchParams({
			bno: bno
		})
	}).then(response => response.text())
		.then(html => {
			boardDetails.innerHTML = html;
		})
		.catch(error => console.error('Error loading table:', error));
}


function go(url) {
	location.href = url;
}

function del(num) {
	console.log("button pressed" + num)

	if (num == 0) {
		boardBtn1.disabled = true;
		fetch('leedefault.jsp', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded'
			},
			body: new URLSearchParams({
				num: num
			})
		}).then(response => response.text())
			.then(html => {
				boardDetails.innerHTML = html;
			})
			.catch(error => console.error('Error loading table:', error));
	} else if (num == 1) {
		boardBtn2.disabled = true;
		boardBtn2.style.display = 'none';
		boardMain.style.backgroundColor = "#e3c099";
		fetch('leedefault.jsp', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded'
			},
			body: new URLSearchParams({
				num: num
			})
		}).then(response => response.text())
			.then(html => {
				boardDetails.innerHTML = html;
			})
			.catch(error => console.error('Error loading table:', error));
	} else if (num == 2) {
		boardBtn3.disabled = true;
		boardBtn3.style.display = 'none';
		boardMain.style.backgroundColor = "#e3c099";
		fetch('leedefault.jsp', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded'
			},
			body: new URLSearchParams({
				num: num
			})
		}).then(response => response.text())
			.then(html => {
				boardDetails.innerHTML = html;
			})
			.catch(error => console.error('Error loading table:', error));
	}
}


function getPage(pageNo) {
	fetch('leeboard.jsp', {
		method: 'POST',
		headers: {
			'Content-type': 'application/x-www-form-urlencoded'
		},
		body: new URLSearchParams({
			pageNo: pageNo
		})
	}).then(response => response.text())
		.then(html => {
			boardDetails.innerHTML = html;
		}).catch(error => console.error('Error loading next table page', error));
}

function getSearch(searchby, searchValue){
	console.log("Searchby:" + searchby);
	console.log("searchValue:" + searchValue);
	fetch('leeboard.jsp', {
			method: 'POST',
			headers: {
				'Content-type': 'application/x-www-form-urlencoded'
			},
			body: new URLSearchParams({
				searchby: searchby,
				searchValue: searchValue,
			})
		}).then(response => response.text())
			.then(html => {
				boardDetails.innerHTML = html;
			}).catch(error => console.error('Error loading next table page', error));
}