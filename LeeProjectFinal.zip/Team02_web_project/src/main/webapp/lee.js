const navBtn = document.querySelector(".navIcon");
const navLine1 = document.querySelector('.line1');
const navLine2 = document.querySelector('.line2');
const navLine3 = document.querySelector('.line3');
const navMenu = document.querySelector(".menu");
const boardBtn1 = document.querySelector(".btn1");
const boardBtn2 = document.querySelector(".btn2");
const boardBtn3 = document.querySelector(".btn3");
const boardBtn4 = document.querySelector(".btn4");
const boardMain = document.querySelector("main");
const boardDetails = document.querySelector(".board-details");
const newtab = document.querySelector(".btn4");
const btnValue1 = boardBtn1.getAttribute('data-btn');
const btnValue2 = boardBtn2.getAttribute('data-btn');
const btnValue3 = boardBtn3.getAttribute('data-btn');
let btnCount = 0;
let bnoSave = [0, 0, 0];

/* ------------------------------------------------------------------ */
//hamburger nav
navBtn.addEventListener("click", () => {
	navMenu.classList.toggle("active");
	
	navLine1.classList.toggle("act1");
	navLine2.classList.toggle("act2");
	navLine3.classList.toggle("act3");
});

/* ------------------------------------------------------------------ */

//display designated post assigned for each button
boardBtn1.addEventListener("click", (e) => {

	boardMain.style.backgroundColor = "#e3c099";
	fetch('leeshow.jsp', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/x-www-form-urlencoded'
		},
		body: new URLSearchParams({
			btn: btnValue1
		})
	}).then(response => response.text())
		.then(html => {
			boardDetails.innerHTML = html;
		})
		.catch(error => console.error('Error loading table:', error));

});
boardBtn2.addEventListener("click", (e) => {
	boardMain.style.backgroundColor = "#c38452";
	fetch('leeshow.jsp', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/x-www-form-urlencoded'
		},
		body: new URLSearchParams({
			btn: btnValue2
		})
	}).then(response => response.text())
		.then(html => {
			boardDetails.innerHTML = html;
		})
		.catch(error => console.error('Error loading btnNo', error));

});

boardBtn3.addEventListener("click", (e) => {
	boardMain.style.backgroundColor = "#6b3e2e";
	fetch('leeshow.jsp', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/x-www-form-urlencoded'
		},
		body: new URLSearchParams({
			btn: btnValue3
		})
	}).then(response => response.text())
		.then(html => {
			boardDetails.innerHTML = html;
		})
		.catch(error => console.error('Error loading btnNo', error));

});
/* ------------------------------------------------------------------ */

//fetches board via ajax
const toBoard = () => {
	boardMain.style.backgroundColor = "#a1785c";
	boardDetails.innerHTML = "";
	fetch('leeboard.jsp')
		.then(response => response.text())
		.then(html => {
			boardDetails.innerHTML = html;
		})
		.catch(error => console.error('Error loading bno', error));

}
newtab.addEventListener("click", toBoard);
/* ------------------------------------------------------------------ */

//gets detail of clicked bno via ajax
function getDetail(bno) {
	fetch('leedetail.jsp', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/x-www-form-urlencoded'
		},
		body: new URLSearchParams({
			bno: bno
		})
	}).then(response => response.text())
		.then(html => {
			boardDetails.innerHTML = html;
		})
		.catch(error => console.error('Error loading table:', error));
}
/* ------------------------------------------------------------------ */

//creates new tab when table row is clicked and activates getDetail()
function showDetail(bno) {
	//console.log('BNO received:', bno);
	boardDetails.innerHTML = "";

	switch (btnCount) {
		case 0:
			bnoSave[0] = bno;
			console.log("bnoSave[0]:" + bnoSave[0]);
			boardMain.style.backgroundColor = "#e3c099";
			console.log("btnCount:" + btnCount);
			btnCount += 1;
			break;

		case 1:
			bnoSave[1] = bno;
			console.log("bnoSave[1]:" + bnoSave[1]);
			boardBtn2.classList.add("active");
			boardMain.style.backgroundColor = "#c38452";
			console.log("btnCount:" + btnCount);
			btnCount += 1;
			break;

		case 2:
			bnoSave[2] = bno;
			console.log("bnoSave[2]:" + bnoSave[2]);
			boardMain.style.backgroundColor = "#6b3e2e";
			boardBtn3.classList.add("active");
			console.log("btnCount:" + btnCount);
			btnCount += 1;

			break;

		default:
			break;
	}
	if (btnCount > 3) {
		alert("max tab reached, please close a tab");
	}

	getDetail(bno);

}
/* ------------------------------------------------------------------ */

//redirect page with href
function go(url) {
	location.href = url;
}
/* ------------------------------------------------------------------ */

//deletes tab and shows previous page and button
function del(num) {
	console.log("button pressed" + num)

	if (num == 0) {
		btnCount--;
		bnoSave[0] = 0;
		console.log(bnoSave);
		fetch('leedefault.jsp', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded'
			},
			body: new URLSearchParams({
				num: num
			})
		}).then(response => response.text())
			.then(html => {
				boardDetails.innerHTML = html;
			})
			.catch(error => console.error('Error loading table:', error));
	} else if (num == 1) {
		btnCount--;
		boardBtn2.classList.remove("active");
		boardMain.style.backgroundColor = "#e3c099";
		bnoSave[1] = 0;
		console.log(bnoSave);
		getDetail(bnoSave[0]);

	} else if (num == 2) {
		btnCount--;
		boardBtn3.classList.remove("active");
		boardMain.style.backgroundColor = "#c38452";
		bnoSave[2] = 0;
		console.log(bnoSave);
		getDetail(bnoSave[1]);

	}
}

/*------------------------------------------------- */
//fetches edit page and loads info stored in db using bno

function edit(bno) {
	console.log(bno)
	confirm('Edit post?');
	if (confirm) {

		fetch('leeedit.jsp', {
			method: 'POST',
			headers: {
				'Content-type': 'application/x-www-form-urlencoded'
			},
			body: new URLSearchParams({
				bno: bno
			})
		}).then(response => response.text())
			.then(html => { boardDetails.innerHTML = html; })
			.catch(error => console.error("error loading edit page", error));

	} else {
		alert("post editing cancelled")
	}
}

function update(btitle, bcontent, bno) {
	btitle = document.querySelector("#btitle").value;
	bcontent = document.querySelector("#bcontent").value;
	bno = document.querySelector("#bno").value;
	console.log("btitle:" + btitle, "bcontent:" + bcontent, "bno:" + bno);
	fetch('leeupdate.jsp', {
		method: 'POST',
		headers: {
			'Content-type': 'application/x-www-form-urlencoded'
		},
		body: new URLSearchParams({
			btitle: btitle,
			bcontent: bcontent,
			bno: bno

		})
	}).then(response => response.text())
		.then(html => { boardDetails.innerHTML = html; })
		.catch(error => console.error("error loading edit page", error));

}

/*------------------------------------------------- */
//function getPage: gets PageNo and sends appropriate page
function getPage(pageNo) {
	fetch('leeboard.jsp', {
		method: 'POST',
		headers: {
			'Content-type': 'application/x-www-form-urlencoded'
		},
		body: new URLSearchParams({
			pageNo: pageNo
		})
	}).then(response => response.text())
		.then(html => {
			boardDetails.innerHTML = html;
		}).catch(error => console.error('Error loading next table page', error));
}

/*------------------------------------------------------ */
function selectOp() {
	option = searchby.options[searchby.selectedIndex].value;
	console.log(option);
	return option;
}
//getSearch: theoretically gets result from search- doesn't work yet: cl returns nothing
function getSearch(searchby, searchValue) {
	searchValue = document.querySelector("#searchValue").value;
	console.log("Searchby:" + searchby);
	console.log("searchValue:" + searchValue);
	fetch('leeboard.jsp', {
		method: 'POST',
		headers: {
			'Content-type': 'application/x-www-form-urlencoded'
		},
		body: new URLSearchParams({
			searchby: searchby,
			searchValue: searchValue,
		})
	}).then(response => response.text())
		.then(html => {
			boardDetails.innerHTML = html;
		}).catch(error => console.error('Error loading next table page', error));
}
/*--------------------------------------------------- */
//delete() deletes selected post using bno
function deletePost(bno) {
	console.log("bno" + bno);
	confirm('delete this post?');

	if (confirm) {
		fetch('leedelete.jsp', {
			method: 'POST',
			headers: {
				'Content-type': 'application/x-www-form-urlencoded'
			},
			body: new URLSearchParams({
				bno: bno
			})
		}).then(response => response.text())
			.then(html => {
				boardDetails.innerHTML = html;
			}).catch(error => console.error('Error deleting post', error));
	} else {
		alert('Post deletion cancelled.');
	}
}

function newPost() {
	fetch('leenew.jsp').then(response => response.text()).then(html => {
		boardDetails.innerHTML = html;
	}).catch(error => console.error('error creating new post', error));
}

function createNew(btitle,bwrite, bcontent) {
	btitle = document.querySelector('#btitle').value;
	bwrite = document.querySelector('#bwrite').value;
	bcontent = document.querySelector('#bcontent').value;
	console.log("btitle :" + btitle);
	console.log("bconent :" + bcontent);
	console.log("bwrite :" + bwrite);

	fetch('leeboard.jsp', {
		method: 'POST',
		headers: {
			'Content-type': 'application/x-www-form-urlencoded'},
		body: new URLSearchParams({
			btitle: btitle,
			bwrite:bwrite,
			bcontent: bcontent,
		})
	}).then(response => response.text())
			.then(html => {
				boardDetails.innerHTML = html;
			}).catch(error => console.error('error adding new page', error));
	};
