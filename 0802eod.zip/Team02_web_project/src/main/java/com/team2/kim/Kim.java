package com.team2.kim;

public class Kim {

}
