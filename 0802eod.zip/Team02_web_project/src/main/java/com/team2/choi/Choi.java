package com.team2.choi;

public class Choi {

}
