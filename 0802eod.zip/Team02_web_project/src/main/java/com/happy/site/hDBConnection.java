package com.happy.site;

import java.sql.Connection;
import java.sql.DriverManager;

public class hDBConnection {
	public Connection getConnection() {
		 Connection con=null;
		 try {
			Class.forName("org.mariadb.jdbc.Driver");
		 String url="jdbc:mariadb://db.wisejia.com:3303/team02";
		 con = DriverManager.getConnection(url, "team02", "team02");
		 } catch (Exception e) {
			 e.printStackTrace();
			 System.out.println("실패");
		 }
		 return con;
	}
}
