package com.team2.lee;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.spi.DirStateFactory.Result;

import com.team02.dao.DBConnection;

public class LeeDAO {
	static int[] detailArr = new int[3];

	private void close(Connection conn, PreparedStatement pstmt, ResultSet rs) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	public List<Map<String, Object>> list(Map<String, Object> search) {
		System.out.println("search pageNo :" + search);
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		Connection conn = DBConnection.getInstance().getConn();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT totalcount, bno, btitle, bwrite,bdate,blike,bcount FROM boardLee LIMIT ?,10";

		if (search.containsKey("searchby")) {
			String title = "";
			switch (String.valueOf(search.get("searchby"))) {
			case "name":
				title = "bwrite";
				break;

			case "content":
				title = "bcontent";
				break;

			case "title":
				title = "btitle";
				break;
			}

			sql = "SELECT totalcount, bno, btitle, bwrite," + "bdate,blike,bcount FROM boardLee WHERE " + title
					+ " LIKE CONCAT('%', ?,'%') LIMIT ?,10 ";
		}
		try {
			pstmt = conn.prepareStatement(sql);
			if (search.containsKey("searchby")) {
				pstmt.setString(1, String.valueOf(search.get("searchValue")));
				pstmt.setInt(2, (Integer.parseInt(String.valueOf(search.get("pageNo"))) - 1) * 10);
			} else {
				pstmt.setInt(1, (Integer.parseInt(String.valueOf(search.get("pageNo"))) - 1) * 10);
			}
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Map<String, Object> e = new HashMap<String, Object>();
				e.put("totalcount", rs.getInt(1));
				e.put("bno", rs.getString(2));
				e.put("btitle", rs.getString(3));
				e.put("bwrite", rs.getString(4));
				e.put("bdate", rs.getString(5));
				e.put("blike", rs.getInt(6));
				e.put("bcount", rs.getInt(7));
				list.add(e);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(conn, pstmt, rs);
		}
		return list;
	}

	public static void store(int bno) {
		if (detailArr[0] == 0) {
			detailArr[0] = bno;
			System.out.println(Arrays.toString(detailArr));

		} else if (detailArr[0] != 0 && detailArr[1] == 0) {
			detailArr[1] = bno;
			System.out.println(Arrays.toString(detailArr));

		} else if (detailArr[0] != 0 && detailArr[1] != 0 && detailArr[2] == 0) {
			detailArr[2] = bno;
			System.out.println(Arrays.toString(detailArr));

		} else {
			System.out.println("store limit: 3 reached. sending alert in front");
			System.out.println(Arrays.toString(detailArr));

		}

	}

	public int sendBno(int btn) {
		int bno = detailArr[btn];
		return bno;

	}

	public LeeDTO detail(int bno) {

		LeeDTO dto = new LeeDTO();
		Connection conn = DBConnection.getInstance().getConn();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT bno, btitle,bcontent,bwrite,bdate,blike,bcount FROM boardLee WHERE bno=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bno);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				dto.setBno(rs.getInt("bno"));
				dto.setBtitle(rs.getString("btitle"));
				dto.setBcontent(rs.getString("bcontent"));
				dto.setBwrite(rs.getString("bwrite"));
				dto.setBdate(rs.getString("bdate"));
				dto.setBlike(rs.getInt("blike"));
				dto.setBcount(rs.getInt("bcount"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(conn, pstmt, rs);
		}

		return dto;
	}

	public void deleteTab(int num) {
		detailArr[num] = 0;
		System.out.println(Arrays.toString(detailArr));
	}

	public void edit(String btitle, String bcontent, int bno) {
		Connection conn = DBConnection.getInstance().getConn();
		PreparedStatement pstmt = null;
		String sql = "UPDATE boardLee SET btitle=?, bcontent=? WHERE bno=? ";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, btitle);
			pstmt.setString(2, bcontent);
			pstmt.setInt(3, bno);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(conn, pstmt, null);
		}
	}

}
