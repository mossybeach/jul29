package com.team2.lee;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/leedetail")
public class Leedetail extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Leedetail() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		System.out.println("Received BNO: " + request.getParameter("bno"));
		int bno = Integer.parseInt(request.getParameter("bno"));
		LeeDAO dao = new LeeDAO();
		LeeDTO dto = dao.detail(bno);
		RequestDispatcher rd = request.getRequestDispatcher("leedetail.jsp");
		request.setAttribute("detail", dto);
		rd.forward(request, response);*/
	}
}

/*
 * System.out.println(request.getParameter("bno")); int bno =
 * Integer.parseInt(request.getParameter("bno")); LeeDAO dao = new LeeDAO();
 * LeeDTO dto = dao.detail(bno); System.out.println(dto); RequestDispatcher rd =
 * request.getRequestDispatcher("leedetail.jsp"); request.setAttribute("detail",
 * dto); rd.forward(request, response); }
 */