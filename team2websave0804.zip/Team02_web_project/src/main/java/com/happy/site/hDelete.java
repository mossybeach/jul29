package com.happy.site;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.happy.checker.Checker;


@WebServlet("/delete-h")
public class hDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public hDelete() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		if(Checker.numCheck(request.getParameter("b_no"))) {
			hDBData db=new hDBData();
			int b_no=Integer.parseInt(request.getParameter("b_no"));
			boolean check = true;
			if(request.getParameter("n")!=null){
			check = false;	
			}
			if(session.getAttribute("name")!=null&&session.getAttribute("name").equals(db.getContent(b_no, check).getWrite())){
				db.delete(b_no, check);
				response.sendRedirect("board-h?p=1");
			}else {
				if(check) {
					response.sendRedirect("detail-h?b_no="+b_no+"&er=noAuth");
				}else {
					response.sendRedirect("detail-h?b_no="+b_no+"&er=noAuth&n=1;");
				}
			}
		}else {
			response.sendRedirect("board-h?p=1");
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
