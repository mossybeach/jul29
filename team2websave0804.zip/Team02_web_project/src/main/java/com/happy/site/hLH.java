package com.happy.site;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.happy.checker.Checker;

@WebServlet("/LH-h")
public class hLH extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public hLH() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("board-h");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		hDBData db=new hDBData();
		boolean like;
		int b_no;
		int where;
		if(Checker.numCheck(request.getParameter("b_no"))&&Checker.numCheck(request.getParameter("where"))) {
			b_no=Integer.parseInt(request.getParameter("b_no"));
			where=Integer.parseInt(request.getParameter("where"));
		}else {
			b_no=0;
			where=0;
			response.sendRedirect("board-h?p=1&er=noexist");
		}

		if(request.getParameter("like").equals("true")){
			like = true;
		}else if(request.getParameter("like").equals("false")){
			like = false;
		}else{
			like = false;
			response.sendRedirect("detail-h?b_no="+b_no+"&er=wrong");
		}
		if(session.getAttribute("name")!=null){
			String result=db.setLH(where, (String)session.getAttribute("name"),request.getParameter("b_no"),like);
			if(result.equals("0")){
				response.sendRedirect("detail-h?b_no="+b_no+"&er=hated"); //이미 비추천
			}else if(result.equals("1")){
				response.sendRedirect("detail-h?b_no="+b_no+"&er=liked"); // 이미 추천
			}else if(result.equals("2")){
				if(like){
					if(db.like(where, b_no, true)) {	
						response.sendRedirect("detail-h?b_no="+b_no+"&er=like"); // 추천 성공
					}else {
						response.sendRedirect("detail-h?b_no="+b_no+"&er=likeFail");	//추천 실패
					}
				}else{
					if(db.like(where, b_no, false)) {						
						response.sendRedirect("detail-h?b_no="+b_no+"&er=hate"); // 비추 성공
					}else {
						response.sendRedirect("detail-h?b_no="+b_no+"&er=hateFail");	// 비추 실패					
					}
				}
			}else if(result.equals("3")){
				response.sendRedirect("detail-h?b_no="+b_no+"&er=sql"); //sql 에러
			}else{
				response.sendRedirect("detail-h?b_no="+b_no+"&er=unknown"); //원인불명 에러
			}
		}else {
			response.sendRedirect("detail-h?b_no="+b_no+"&er=notUser"); //비로그인 접근
		}
	}
}
