package com.happy.site;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class hDBData {
	public List<hBoardDTO> getBoard(String asql, String val, int p, int tp){//불러오기
		List<hBoardDTO> result=new ArrayList<hBoardDTO>();
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql;
		hDBConnection dbConnection=new hDBConnection();
		try {
			if(asql.equals(" where b_content like ?")) {
				sql="SELECT bv.* FROM hboardview bv JOIN ( SELECT b_no FROM hboard"+asql+") b_f WHERE bv.b_no = b_f.b_no LIMIT ?, ?";		
			}else {
				sql="SELECT * FROM hboardview"+asql+" limit ?,?";
			}
			pstmt=dbConnection.getConnection().prepareStatement(sql);
			if(tp-(p*20)>0) {
				if(asql.equals(" where b_title like ?")||asql.equals(" where b_content like ?")) {
					pstmt.setString(1,"%" + val + "%");
					pstmt.setInt(2,p*20-20);
					pstmt.setInt(3,20);
				}else if(asql.equals(" where b_write=?")){
					pstmt.setString(1,val);
					pstmt.setInt(2,p*20-20);
					pstmt.setInt(3,20);
				}else {
					pstmt.setInt(1,p*20-20);
					pstmt.setInt(2,20);	
				}
			}else {
				if(asql.equals(" where b_title like ?")||asql.equals(" where b_content like ?")) {
					pstmt.setString(1,"%" + val + "%");
					pstmt.setInt(2,p*20-20);
					pstmt.setInt(3,20-(p*20-tp));
				}else if(asql.equals(" where b_write=?")){
					pstmt.setString(1,val);
					pstmt.setInt(2,p*20-20);
					pstmt.setInt(3,20-(p*20-tp));
				}else {
					pstmt.setInt(1,p*20-20);
					pstmt.setInt(2,20-(p*20-tp));
				}
			}
			rs=pstmt.executeQuery();
			for(;rs.next();) {
				hBoardDTO dto=new hBoardDTO();
				dto.setNo(rs.getInt("b_no"));
				dto.setTitle(rs.getString("b_title"));
				dto.setWrite(rs.getString("b_write"));
				dto.setDate(rs.getString("b_date"));
				dto.setLike(rs.getInt("b_like"));
				dto.setHate(rs.getInt("b_hate"));
				dto.setRead(rs.getInt("b_count"));
				result.add(dto);
			}
		} catch (SQLException e) {
			System.out.println("대실패");
		}finally {
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	}
	public hBoardDTO getContent(int b_no, boolean check){//불러오기
		hBoardDTO result=new hBoardDTO();
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql;
		if(check) {
			sql= "SELECT * FROM hboard where b_no=?";
		}else {
			sql= "SELECT * FROM hboardN where b_no=?";
		}
		hDBConnection dbConnection=new hDBConnection();
		try {
			pstmt=dbConnection.getConnection().prepareStatement(sql);
			pstmt.setInt(1,b_no);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				result.setNo(rs.getInt("b_no"));
				result.setTitle(rs.getString("b_title"));
				result.setContent(rs.getString("b_content"));
				result.setWrite(rs.getString("b_write"));
				result.setDate(rs.getString("b_date"));
				result.setLike(rs.getInt("b_like"));
				result.setHate(rs.getInt("b_hate"));
				result.setRead(rs.getInt("b_count"));
			}
		} catch (SQLException e) {
			System.out.println("대실패");
		}finally {
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public List<hBoardDTO> getBoardN(){//불러오기
		List<hBoardDTO> result=new ArrayList<hBoardDTO>();
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql = "SELECT * FROM hboardNview";
		
		hDBConnection dbConnection=new hDBConnection();
		try {
			pstmt=dbConnection.getConnection().prepareStatement(sql);
			rs=pstmt.executeQuery();
			for(;rs.next();) {
				hBoardDTO dto=new hBoardDTO();
				dto.setNo(rs.getInt("b_no"));
				dto.setNNo(rs.getString("n_no"));
				dto.setTitle(rs.getString("b_title"));
				dto.setWrite(rs.getString("b_write"));
				dto.setDate(rs.getString("b_date"));
				dto.setLike(rs.getInt("b_like"));
				dto.setHate(rs.getInt("b_hate"));
				dto.setRead(rs.getInt("b_count"));
				result.add(dto);
			}
		} catch (SQLException e) {
			System.out.println("대실패");
		}finally {
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
		return result;
	}
	public boolean setBoard(String tt, String ct, String wt){//작성
		hDBConnection dbConnection=new hDBConnection();
		String sql = "INSERT INTO hboard (b_title, b_content, b_write) "
				+ "VALUE (?, ?, ?);";
		try {
			PreparedStatement pstmt=dbConnection.getConnection().prepareStatement(sql);
			pstmt.setString(1,tt);
			pstmt.setString(2,ct);
			pstmt.setString(3,wt);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			return false;
		}
		return true;
	}
	public boolean edit(String tt, String ct, String no, boolean check){//작성
		hDBConnection dbConnection=new hDBConnection();
		String sql;
		if(check) {
			sql="UPDATE hboard SET b_title=?, b_content=? where b_no=?;";
		}else {
			sql="UPDATE hboardN SET b_title=?, b_content=? where b_no=?;";
		}
		try {
			PreparedStatement pstmt=dbConnection.getConnection().prepareStatement(sql);
			pstmt.setString(1,tt);
			pstmt.setString(2,ct);
			pstmt.setString(3,no);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			return false;
		}
		return true;
	}
	public boolean view(int view, int no, boolean check){//작성
		hDBConnection dbConnection=new hDBConnection();
		String sql;
		if(check) {
			sql="UPDATE hboard SET b_count=? where b_no=?;";
		}else {
			sql="UPDATE hboardN SET b_count=? where b_no=?;";
		}
		try {
			PreparedStatement pstmt=dbConnection.getConnection().prepareStatement(sql);
			pstmt.setInt(1,view);
			pstmt.setInt(2,no);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			return false;
		}
		return true;
	}
	public boolean delete(int b_no, boolean check){//작성
		hDBConnection dbConnection=new hDBConnection();
		String sql;
		if(check) {
			sql= "Delete from hboard where b_no=?;";
		}else {
			sql= "Delete from hboardN where b_no=?;";
		}
		try {
			PreparedStatement pstmt=dbConnection.getConnection().prepareStatement(sql);
			pstmt.setInt(1,b_no);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			return false;
		}
		return true;
	}
	public String login(String id, String pw){
		String name=null;
		hDBConnection dbConnection=new hDBConnection();
		String sql = "Select m_name from member where m_id=? and m_pw=?;";
		try {
			PreparedStatement pstmt=dbConnection.getConnection().prepareStatement(sql);
			pstmt.setString(1,id);
			pstmt.setString(2,pw);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()) {
			name=rs.getString("m_name");
			rs.close();
			pstmt.close();
			}
		} catch (SQLException e) {
			return "오류";
		}
		return name;
	}
	public int getUser(String name){//불러오기
		int result=0;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql = "SELECT * FROM member where m_name=?";
		
		hDBConnection dbConnection=new hDBConnection();
		try {
			pstmt=dbConnection.getConnection().prepareStatement(sql);
			pstmt.setString(1,name);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				result=rs.getInt("m_no");
			}
		} catch (SQLException e) {
			System.out.println("대실패");
		}finally {
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
		return result;
	}
	public int totalPost(String req, String val){
		String sql="SELECT COUNT(*) FROM hboard";
		if(!req.equals("")&&req!=null){
			sql+= req;
		}
		int totalPost = 0;

		hDBConnection dbConnection = new hDBConnection();
		try {
		    // 총 게시물 수를 가져오는 쿼리 실행
		    PreparedStatement pstmt = dbConnection.getConnection().prepareStatement(sql);
			if(req.equals(" where b_title like ?")||req.equals(" where b_content like ?")) {
				pstmt.setString(1, "%" + val + "%");
			}else if(req.equals(" where b_write=?")) {
				pstmt.setString(1, val);
			}
		    ResultSet rs = pstmt.executeQuery();
		    if (rs.next()) {
		    	totalPost=rs.getInt(1);
		    }
		} catch (SQLException e) {
			e.printStackTrace();
		    return 10;
		}
		return totalPost;
	}
	public String setLH(int where, String name, String b_no, boolean LH){//작성
		hDBConnection dbConnection=new hDBConnection();
		int m_no=getUser(name);
		String LHval;
		String from="b_no1";;
		if(where==2) {
			from="b_no2";
		}
		if(LH) {
			LHval="1";
		}else{
			LHval="0";
		}
		try {
			String sql = "SELECT lh from hlikehate where m_no=? AND "+from+"=?";
			PreparedStatement pstmt=dbConnection.getConnection().prepareStatement(sql);
			pstmt.setInt(1,m_no);
			pstmt.setString(2,b_no);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getString("lh");
			}else {
				sql = "INSERT INTO hlikehate (`m_no`, "+from+", `lh`) VALUES (?, ?, ?);";
				pstmt=dbConnection.getConnection().prepareStatement(sql);
				pstmt.setInt(1,m_no);
				pstmt.setString(2,b_no);
				pstmt.setString(3,LHval);
				pstmt.executeUpdate();
				return "2";
			}
		} catch (SQLException e) {
			return "3";
		}
	}
	public boolean like(int where, int b_no, boolean lh){//작성
		hDBConnection dbConnection=new hDBConnection();
		String sql;
		String sql1;
		String sql2;
		if(where==2) {
			sql1="UPDATE hboard SET ";
			sql2="=? where b_no=?;";
		}else {
			sql1="UPDATE hboardN SET ";
			sql2="=? where b_no=?;";
		}
		if(lh) {
			sql=sql1+"b_like"+sql2;
		}else {
			sql=sql1+"b_hate"+sql2;			
		}
		try {
			PreparedStatement pstmt=dbConnection.getConnection().prepareStatement(sql);
			if(lh) {
				pstmt.setInt(1,getContent(b_no, where==2).getLike()+1);
			}else {
				pstmt.setInt(1,getContent(b_no, where==2).getHate()+1);
			}
			pstmt.setInt(2,b_no);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			return false;
		}
		return true;
	}
}
