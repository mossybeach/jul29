package com.team2.lee;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Board extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Board() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*LeeDAO dao = new LeeDAO();
		List<LeeDTO> list = dao.list();
		request.setAttribute("list", list);
		RequestDispatcher rd = request.getRequestDispatcher("/main/webapp/LEE/leeboard.jsp");
		rd.forward(request, response);
		System.out.println(rd);*/
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

}
