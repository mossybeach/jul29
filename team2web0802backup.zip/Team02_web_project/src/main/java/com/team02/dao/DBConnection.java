package com.team02.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
	private static DBConnection dbConnection;

	public static DBConnection getInstance() {
		if (dbConnection == null) {
			dbConnection = new DBConnection();
		}
		return dbConnection;
	}

	private DBConnection() {}

	public Connection getConn() {
		Connection conn = null;
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			String url = "jdbc:mariadb://db.wisejia.com:3303/team02";
			conn = DriverManager.getConnection(url, "team02", "team02");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
}
