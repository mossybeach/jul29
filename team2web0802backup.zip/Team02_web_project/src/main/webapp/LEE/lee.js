const navBtn = document.querySelector(".navIcon");
const navMenu = document.querySelector(".menu");
const boardBtn1 = document.querySelector(".btn1");
const boardBtn2 = document.querySelector(".btn2");
const boardBtn3 = document.querySelector(".btn3");
const boardBtn4 = document.querySelector(".btn4");
const boardMain = document.querySelector("main");
const boardDetails = document.querySelector(".board-details");

const newtab = document.querySelector(".btn4");

navBtn.addEventListener("click", () => {
	navMenu.classList.toggle("active");
});

boardBtn1.addEventListener("click", () => {
	boardMain.style.backgroundColor = "#e3c099";
	boardImg.src = "img/image1.jpg";
});
boardBtn2.addEventListener("click", () => {
	boardMain.style.backgroundColor = "#c38452";
	boardImg.src = "img/image2.jpg";
});

boardBtn3.addEventListener("click", () => {
	boardMain.style.backgroundColor = "#6b3e2e";
	boardImg.src = "img/image3.jpg";
});
newtab.addEventListener("click", () => {
	boardMain.style.backgroundColor = "#a1785c";
	boardDetails.innerHTML = "";
	fetch('leeboard.jsp')
		.then(response => response.text())
		.then(html => {
			boardDetails.innerHTML = html;
		})
		.catch(error => console.error('Error loading table:', error));
});

let btnCount = 0;

function showDetail(bno) {
	console.log('BNO received:', bno);
	boardDetails.innerHTML = "";

	switch (btnCount) {
		case 0:
			btnCount += 1;
			boardMain.style.backgroundColor = "#e3c099";
			break;

		case 1:
			btnCount += 1;
			boardBtn2.classList.add("active");
			boardMain.style.backgroundColor = "#c38452";
			break;

		case 2: boardMain.style.backgroundColor = "#6b3e2e";
			boardBtn3.classList.add("active");
			break;

		default:
			alert("max tab reached, please close a tab");
			break;
	}

	fetch('leedetail.jsp', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/x-www-form-urlencoded'
		},
		body: new URLSearchParams({
			bno: bno
		})
	}).then(response => response.text())
		.then(html => {
			boardDetails.innerHTML = html;
		})
		.catch(error => console.error('Error loading table:', error));


	if (btnCount > 3) {
		alert("max tab reached, please close a tab");
	}
}





function go(url) {
	location.href = url;
}




