package com.happy.site;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/editS")
public class hEditS extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public hEditS() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("edit-h");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String tt=request.getParameter("title");
		String ct=request.getParameter("editordata");
		String no=request.getParameter("no");
		boolean check=true;
		if(request.getParameter("check").equals("false")) {
			check=false;
		};
		hDBData db=new hDBData();
		if(db.edit(tt, ct, no, check)){
			if(check) {
				response.sendRedirect("detail-h?b_no="+no);
			}else {
				response.sendRedirect("detail-h?b_no="+no+"&n=1");
			}
		}else {
			response.sendRedirect("edit-h?b_no="+no+"&er=writeerror");
		}
		
	}

}
