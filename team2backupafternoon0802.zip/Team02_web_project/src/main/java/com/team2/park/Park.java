package com.team2.park;

public class Park {

}
