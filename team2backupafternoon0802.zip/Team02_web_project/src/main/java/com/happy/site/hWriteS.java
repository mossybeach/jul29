package com.happy.site;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/writeS")
public class hWriteS extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public hWriteS() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("write-h.jsp");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String tt=request.getParameter("title");
		String ct=request.getParameter("editordata");
		String nn=request.getParameter("nickname");
		HttpSession session = request.getSession();
		hDBData db=new hDBData();
		if(db.setBoard(tt, ct, nn)){
			response.sendRedirect((String)session.getAttribute("page"));
		}else {
			response.sendRedirect("write-h?error=writeerror");
		}
		
	}

}
