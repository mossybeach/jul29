package com.happy.checker;

public class Checker {
	public static boolean numCheck(String no) {
		if (no != null && !no.trim().isEmpty()) {
			try {
				int bno = Integer.parseInt(no);
				if (bno > 0) {
					return true;
				} else {
					return false;
				}
			} catch (NumberFormatException e) {
				return false;
			}
		} else {
			return false;
		}
	}
}
